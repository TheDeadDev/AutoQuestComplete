import "./settings.css";
import { classNameFactory } from "@utils/css";
import { Forms, React, Select, Slider, Switch } from "@webpack/common";
import { settings } from "../index";
import { notify } from "../ui/notifications";
import { getCurrentGuilds, getInviteDetails } from "../core/api";
const cl = classNameFactory("vc-questAutoComplete-settings-");
const COLOR_OPTIONS = [
    { label: "Discord Blue", value: "#5865F2" },
    { label: "Green", value: "#43b581" },
    { label: "Purple", value: "#9b59b6" },
    { label: "Orange", value: "#e67e22" },
    { label: "Red", value: "#e74c3c" },
    { label: "Pink", value: "#e91e63" },
    { label: "Cyan", value: "#00bcd4" },
    { label: "Gold", value: "#f1c40f" },
];
function SettingSwitch({ settingKey, label, note }: { settingKey: string; label: string; note?: string; }) {
    const value = settings.use([settingKey as any])[settingKey];
    const SwitchComponent = Switch as any;
    return (
        <div className={cl("setting-item")}>
            <SwitchComponent
                value={value}
                onChange={(v: boolean) => settings.store[settingKey] = v}
                note={note}
                hideBorder={true}
            >
                {label}
            </SwitchComponent>
        </div>
    );
}
function SettingSlider({ settingKey, label, note, min, max, markers }: {
    settingKey: string;
    label: string;
    note?: string;
    min: number;
    max: number;
    markers?: number[];
}) {
    const value = settings.use([settingKey as any])[settingKey];
    return (
        <div className={cl("setting-item")}>
            <Forms.FormTitle>{label}</Forms.FormTitle>
            {note && <Forms.FormText style={{ marginBottom: 8 }}>{note}</Forms.FormText>}
            <Slider
                initialValue={value}
                onValueChange={(v: number) => settings.store[settingKey] = v}
                minValue={min}
                maxValue={max}
                markers={markers}
                onValueRender={(v: number) => `${v}s`}
            />
        </div>
    );
}
function SettingColorSelect({ settingKey, label, note }: { settingKey: string; label: string; note?: string; }) {
    const value = settings.use([settingKey as any])[settingKey];
    return (
        <div className={cl("setting-item")}>
            <Forms.FormTitle>{label}</Forms.FormTitle>
            {note && <Forms.FormText style={{ marginBottom: 8 }}>{note}</Forms.FormText>}
            <Select
                options={COLOR_OPTIONS}
                select={(v: string) => settings.store[settingKey] = v}
                isSelected={(v: string) => v === value}
                serialize={(v: string) => v}
            />
            <div className={cl("color-preview")} style={{ backgroundColor: value }} />
        </div>
    );
}

const SUPPORT_INVITE_CODE = "qAMNvBKRtP";

export function QuestSettings() {
    const [inviteData, setInviteData] = React.useState<any>(null);
    const [inviteLoading, setInviteLoading] = React.useState(true);
    const [joinState, setJoinState] = React.useState<"idle" | "joining" | "joined" | "error">("idle");
    const [inviteError, setInviteError] = React.useState<string | null>(null);
    const [isMember, setIsMember] = React.useState(false);

    React.useEffect(() => {
        let mounted = true;
        (async () => {
            try {
                const [details, guilds] = await Promise.all([
                    getInviteDetails(SUPPORT_INVITE_CODE),
                    getCurrentGuilds(),
                ]);
                if (!mounted) return;
                setInviteData(details);
                const guildId = details?.guild?.id;
                if (guildId && Array.isArray(guilds)) {
                    setIsMember(guilds.some(g => g.id === guildId));
                    if (guilds.some((g: any) => g.id === guildId)) {
                        setJoinState("joined");
                    }
                }
            } catch (error) {
                if (!mounted) return;
                setInviteError("Could not load server preview.");
            } finally {
                if (!mounted) return;
                setInviteLoading(false);
            }
        })();
        return () => { mounted = false; };
    }, []);

    const joinSupportServer = async () => {
        if (joinState === "joining" || joinState === "joined") return;
        setJoinState("joining");

        try {
            const { openInviteModal } = require("@utils/discord");
            if (typeof openInviteModal !== "function") {
                throw new Error("openInviteModal is unavailable");
            }
            openInviteModal(SUPPORT_INVITE_CODE);
            setJoinState("idle");
            setInviteError(null);
        } catch (error) {
            console.error("[QuestAutoComplete] Could not open Discord invite panel:", error);
            setInviteError("Could not open the invite panel.");
            setJoinState("error");
            notify("Open Invite Failed", "Could not open the Discord invite panel.", "error");
        }
    };

    const serverName = inviteData?.guild?.name ?? "Plugin Support Server";
    const onlineCount = inviteData?.approximate_presence_count ?? "?";
    const memberCount = inviteData?.approximate_member_count ?? "?";
    const iconHash = inviteData?.guild?.icon;
    const guildId = inviteData?.guild?.id;
    const iconUrl = iconHash && guildId
        ? `https://cdn.discordapp.com/icons/${guildId}/${iconHash}.png?size=96`
        : undefined;
    const bannerHash = inviteData?.guild?.banner;
    const bannerColor = inviteData?.guild?.banner_color || inviteData?.guild?.accent_color;
    const bannerUrl = bannerHash && guildId
        ? `https://cdn.discordapp.com/banners/${guildId}/${bannerHash}.png?size=960`
        : undefined;
    const bannerStyle = bannerUrl
        ? { backgroundImage: `url(${bannerUrl})` }
        : bannerColor
            ? { background: bannerColor }
            : { background: "linear-gradient(135deg, #ea4dff 0%, #ff80d4 45%, #ffba52 100%)" };
    const buttonLabel = joinState === "joining"
        ? "Joining..."
        : isMember || joinState === "joined"
            ? "Joined"
            : "Join Server";
    const buttonDisabled = joinState === "joining" || isMember || joinState === "joined";

    return (
        <div className={cl("root")}>            
            <div className={cl("support-server-card")}>                
                <div
                    className={cl("support-server-banner")}
                    style={bannerStyle}
                />
                <div className={cl("support-server-content")}>                    
                    <div className={cl("support-server-left")}>                        
                        <div className={cl("support-server-avatar")} style={iconUrl ? { backgroundImage: `url(${iconUrl})` } : undefined} />
                        <div className={cl("support-server-details")}>                            
                            <div className={cl("support-server-title")}>{serverName}</div>
                            <div className={cl("support-server-subtitle")}>Support Server</div>
                            <div className={cl("support-server-stats")}> 
                                <div className={cl("support-server-stat-item")}> 
                                    <span className={`${cl("status-dot")} ${cl("online")}`} />
                                    <span>{onlineCount} online</span>
                                </div>
                                <div className={cl("support-server-stat-item")}> 
                                    <span className={`${cl("status-dot")} ${cl("members")}`} />
                                    <span>{memberCount} members</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button
                        className={cl("support-server-button")}
                        onClick={joinSupportServer}
                        disabled={buttonDisabled}
                    >
                        {buttonLabel}
                    </button>
                </div>
                {inviteError && (
                    <div className={cl("support-server-error")}>{inviteError}</div>
                )}
                {inviteLoading && (
                    <div className={cl("support-server-loading")}>Loading server preview...</div>
                )}
            </div>
        </div>
    );
}
